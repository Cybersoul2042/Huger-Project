document.addEventListener("DOMContentLoaded", () => {
    var _a;
    (_a = document.getElementById('home-btn')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', () => ChangePage('home-btn'));
});
function ChangePage(pagetype) {
    const desiredPage = document.getElementById('');
}
//# sourceMappingURL=index.js.map